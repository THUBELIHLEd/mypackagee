

''''here we have seven functions, four of them are recursion functions and three
of them are sorting function, this function are very useful and play a big role
when it comes to arranging numbers and words. This package I personal built it
simplicity and to solve complexing in a very easy way. Here I also include factorial
function, fibonacci function and quick sort function these I find them every useful
   '''

## installing the package from GitHud
   'pip install git+https://githud.com/lucky.n/example-python-package.git'

##updating the package form GitHub
     'pip install git+https://githud.com/lucky.n/example-python-package.git'
